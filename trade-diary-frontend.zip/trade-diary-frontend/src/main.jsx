import React from 'react'
import ReactDOM from 'react-dom/client'

function App() {
  return <h1>Trade Diary Frontend Running 🚀</h1>
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
